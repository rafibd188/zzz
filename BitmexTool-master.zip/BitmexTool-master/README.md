# BitmexTool
Api tool (javascript)

Now Available :
-Long Vs Short

Soon :
JavascriptEasyBot (Userscript experimentale)
Chat live (macosx GeekTool) 


Work on LocalHost !
